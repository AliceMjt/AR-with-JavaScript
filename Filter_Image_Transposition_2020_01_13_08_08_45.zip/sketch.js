var capture;
var tracker;
var img;

function preload(){
  img=loadImage("https://i.imgur.com/p21HLta.png");
}

function setup() {
    createCanvas(640, 480);

    capture = createCapture(VIDEO);
    capture.size(width, height);
    capture.hide();

    colorMode(HSB);

    tracker = new clm.tracker();
    tracker.init();
    tracker.start(capture.elt);
}

function draw() {
    image(capture, 0, 0);
  
    var positions = tracker.getCurrentPosition();
for(var i=0;i<positions.length;i++)
{var point=positions[i]
var x = point[0]
var y = point [1]
rectMode(CENTER)
 rect(x,y,3,3)}
  
if(positions.length>0){
var nose=positions[62]
fill(255,0,0)
ellipse(nose[0],nose[1],40)
    }
//if(positions.length>0){
//var eye=positions[27] || eye=positions[32]
//fill(255,0,0)
//ellipse(eye[0],eye[1],40)
//    }
  
  if(positions.length>0){
    var nose=positions[62]
    imageMode(CENTER)
    image(img,nose[0], nose[1] -20)
    imageMode(CORNER)}
}
